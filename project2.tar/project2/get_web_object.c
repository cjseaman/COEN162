#include "get_web_object.h"

#define INIT_RESP 100

unsigned long domainToIp(char *domain) {
	
	bool is_ip = true;
	int i;
	struct hostent *ip;
	void *address;

	printf("Evaluating Host...");
	ip = gethostbyname(domain);
	if(ip == NULL) {
		printf("Host name could not be found\n");
		return -1;
	}
	address = malloc(ip->h_length);
	memcpy(address, ip->h_addr_list[0], ip->h_length);	
	printf("Host name found\n");
	return *((unsigned long *) address);
}


int establishConnection(unsigned long *ip, int port) {
	struct sockaddr_in server;
	int sock = socket(AF_INET, SOCK_STREAM, 0);
	printf("Creating socket...");
	if(sock == -1) {
		printf("Failed to create socket\n");
		return -1;
	}
	server.sin_addr.s_addr = *ip;
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	printf("Binding to socket...");
	if(bind(sock, (struct sockaddr *) &server, sizeof(server)) < 0) {
		printf("Failed to bind to socket\n");
		return -1;
	}
	else {
		printf("Connection successful\n");
		return sock;
	}
}

char *sendRequest(int sock, char *message) {
	char c, *response;
	int n, i = 0, extra_mem = 1;

	printf("Sending request...");
	n = send(sock, message, strlen(message), 0);
	if(n < 0) {
		printf("Error writing to socket\n");
		return NULL;
	}
	printf("Request sent\n");
	
	response = (char *) malloc(INIT_RESP);
	while(n = recv(sock, response, INIT_RESP, 0) > 0) {
		extra_mem++;
		if(n == INIT_RESP) {
			response = (char *) realloc(response, extra_mem * INIT_RESP);
		}
		else {
			response[n + INIT_RESP * extra_mem] = '\0';
		}
		
		//printf("%s", response);
	}

	if(n < 0) {
		printf("Error reading from socket\n");
		return NULL;
	}

	printf("\n\nRead Completed.\n");
	
	return response;
}

void parseRequest(char *request, char **filename, char **host) {
	
	int i, path_length, host_length;
	char *path_start, *path_end, *host_start, *host_end;
	path_start = strchr(request, '/');
	path_end = strchr(request, ' ');
	path_length = path_end - path_start;
	printf("Path length is %d\n", path_length);
	
	*filename = malloc(path_length + 1);
	memset(*filename, '\0', sizeof(*filename));
	strncpy(*filename, path_start, path_length);
	
	host_start = strchr(request, '\n');
	host_start = strchr(host_start, ' ');
	host_start++;
	host_end = strchr(host_start, '\n');
	host_length = host_end - host_start;
	
	*host = malloc(host_length + 1);
	memset(*host, '\0', sizeof(*host_start));
	strncpy(*host, host_start, host_length);
}

char *getRequest(int sock) {
	char *response;
	int n, extra_mem = 1;
	response = (char *) malloc(INIT_RESP);
	while(n = recv(sock, response, INIT_RESP, 0) > 0) {
		extra_mem++;
		if(n == INIT_RESP) {
			response = realloc(response, extra_mem * INIT_RESP);
		}
		else {
			response[n + INIT_RESP * extra_mem] = '\0';
		}
		
	}

	printf("Waited for %d bytes, %d bytes recieved.\n", INIT_RESP, n);
	
	if(n <= 0) {
		printf("Error reading from socket or no data read from socket\n");
		return NULL;
	}

	printf("\n\nRead Completed.\n");
	
	return response;
}
