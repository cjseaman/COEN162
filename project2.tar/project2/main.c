#include "get_web_object.h"

int main(int argc, char *argv[]) {

	char **filename, **host, *message, *request, *response;
	unsigned long ip, local_host;
	int server_sock, browser_sock, port = 6666;

	if(argc > 1)
		port = atoi(argv[1]);
	
	local_host = inet_addr("127.0.0.1");	
	browser_sock = establishConnection(&local_host, port);
	if(browser_sock == -1) {
		printf("Connection to browser (port %d) failed\n", port);
		return 1;
	}
	printf("Connected to browser on port %d with socket %d\n", port, browser_sock);

	while(1) {

		request = getRequest(browser_sock);
		if(request == NULL) {
			printf("Failed to get request from browser on socket %d\n", browser_sock);
			return 1;
		}
		printf("Parsing request:\n\n%s\n", request);
		parseRequest(request, filename, host);
		
		free(request);
		
		ip = domainToIp(*host);
		if(ip == (unsigned long) -1) {
			printf("Failed to evaluate server address\n");
			return 1;
		}	
		printf("Connecting to server...");
		server_sock = establishConnection(&ip, 80);	
		if(server_sock == -1) {
			printf("Connection to server failed\n");
			return 1;
		}

		printf("Connected\n");
	
		response = sendRequest(server_sock, message);
		printf("Sending response to browser...");		
		send(browser_sock, response, sizeof(response), 0);
		printf("Done\n");
	}
	close(server_sock);
	close(browser_sock);
	return 0;
	
}
